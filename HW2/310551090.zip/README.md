# Self Supervised learning

## Usage
### Dependencies
```
pip install -r requirements.txt
```

### Training
```
python main.py
```

### Evaluation: k-NN
```
python eval_knn.py
```

### Dataset location
hw2
